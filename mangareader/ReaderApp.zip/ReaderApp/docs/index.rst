.. KivyMD documentation master file, created by
   sphinx-quickstart2 on Wed Dec 23 03:40:16 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to KivyMD's documentation!
==================================

.. warning::
    KivyMD is currently in alpha status, so things are changing all the time and we cannot promise any kind of API stability. However it is safe to vendor now and make use of what's currently available; giving you freedom to upgrade when you're ready to do the necessary refactoring.

Contents:

.. toctree::
    :maxdepth: 2

    kivymd.list
    kivymd.bottomsheet
    kivymd.navigationdrawer
    kivymd.snackbar

.. Module contents
.. ---------------
..
.. .. automodule:: kivymd.snackbar
..    :members:
..    :undoc-members:
..    :show-inheritance:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
